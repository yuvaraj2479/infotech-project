import React, { Component } from 'react';
import  {useState,useEffect} from 'react';
import { Button,Modal, Container } from 'react-bootstrap';
import DatePicker from "react-datepicker";
import Navigation from './nav';

import "react-datepicker/dist/react-datepicker.css";
import { AiFillEdit,AiFillDelete } from 'react-icons/ai';

import Form from 'react-bootstrap/Form';

import axios from 'axios';

 
function Example() {
 
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [selectedDate, setselecteDdate]=useState(null)
    const[task,SetTask]=useState('');
    const[status,SetStatus]=useState(false);
    const[remarks,SetRemarks]=useState(''); 
    const[isEdit,setIsedit]=useState(false); 
    const[get,setGet]=useState([]);
    const[id,setId]=useState([]);
    const[user,setUser]=useState('')
    const[name,setName]=useState('');
    
    


    const url='http://localhost:1337/'
    
        
     
function SaveData(e,){
          e.preventDefault()
            const taskdata={
            developer:localStorage.getItem('name'),
            date:selectedDate.toISOString(),
            task:task,
            status:status === true?"DONE":"INPROGRESS",
            remarks:remarks
          }

            
            let con={data:taskdata}
           
            if(isEdit===false){
              axios.post(url+'api/tasks', {
                headers: {
                         'Accept':'application/json',
                         'Content-Type': 'application/json'
              },
                data:taskdata  
            }) 
             
                .then(res=>{
                      console.log(res)    
                      fetchTasks() 
              })
                .catch(err=>{
                  console.log(err)
              })     
            }else{
                 axios.put(url+'api/tasks/'+id, {
                 headers: {
                     'Accept':'application/json',
                     'Content-Type': 'application/json'
                 },
           
                 data:taskdata  
                })             
                .then(res=>{
                     fetchTasks()
                })
                .catch(err=>{
                      console.log(err)
                })  
          }
            setShow(false);
            setselecteDdate("")
            SetTask("")
            SetStatus(false)
            SetRemarks("")
      }
      


     const  handleDelete=(id)=>{
      axios.delete(url+'api/tasks/'+id)
      .then(res=>{
        fetchTasks()
      })
      .catch(err=>{
        console.log(err)
      })

      }

 
       
          const handleEdit=(item,e,id,data)=>{
          setShow(true);
          setIsedit(true);
          setId(item.id)
          
          setselecteDdate(new Date(item.attributes.date));
          SetTask(item.attributes.task);
          SetStatus(item.attributes.status);
          SetRemarks(item.attributes.remarks)  
              
        }



      useEffect(() => {
           fetchTasks() 
    },[]) 


    function fetchTasks(){  
      axios.get(url+'api/tasks')
      .then(res=>{
           console.log(res.data.data)
           setGet(res.data.data)          
      })
      .catch(err=>{
           console.log(err)
      })
    }


       
  return (
    <div >
    <Navigation>
      <Container>
       <div className="container ">
          <div className="crud shadow-lg p-3 mb-5 mt-5 bg-body rounded" style={{width:"1050px",paddingLeft:"500px",margin:"60px"}}> 
          <div className="row ">
           
           <div className="col-sm-3 mt-5 mb-4 text-gred">
                  
              </div>  
              <div className="col-sm-3 offset-sm-2 mt-5 mb-4 text-gred" style={{color:"green"}}><h2><b>Task</b></h2></div>
              <div className="col-sm-3 offset-sm-1  mt-5 mb-4 text-gred" style={{display:"flex",justifyContent:'center'}}>
              <Button variant="primary" onClick={handleShow} style={{marginleft:"500px"}}>
                Add Task
              </Button>
             </div>
           </div>  
            <div className="row">
                <div className="table-responsive " >
                 <table className="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>Developer</th>
                            <th>Date</th>   
                            <th>Task</th>
                            <th>Status</th>
                            <th>Remarks</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                            {get.map((item,id)=>
                              <tr key={id}>
                                <td>{item.attributes.developer}</td>
                                <td>{item.attributes.date}</td>
                                <td>{item.attributes.task}</td>
                                <td>{item.attributes.status}</td>
                                <td>{item.attributes.remarks}</td>
                                <td><AiFillEdit onClick={()=>handleEdit(item)} /> <AiFillDelete onClick={()=>handleDelete(item.id)} /></td>
                              </tr>
                            )}     
                    </tbody>
                </table>
            </div>   
        </div>  
 
    
        <div className="model_box">
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Task</Modal.Title>
        </Modal.Header>
            <Modal.Body>
            <form>
              <div className="form-group" style={{display:"flex"}}>
                <label style={{width:"25%"}}>Developer:</label> 
                <p value={user}>{localStorage.getItem('name')}</p> 
              </div>
                <div className="form-group mt-3"  style={{display:"flex"}}>
                    <label style={{width:"30%"}}>Choose date:</label>

                    <DatePicker className='inputtext'
                     selected={selectedDate}
                     onChange={date=>setselecteDdate(date)}
                     dateFormat='dd/MM/yyyy'
                     value={selectedDate} 
                     />
                </div>

                <div className="form-group mt-3" style={{display:"flex"}}>
                    <label style={{width:"23%"}} >Task:</label>
                   <textarea  value={task} onChange={e=>SetTask(e.target.value)} style={{width:"50%",height:"50px"}} />
                </div>
                <div className="form-group mt-3"  style={{display:"flex"}} >
                    <label style={{width:"22%"}}>Status:</label>
                     
  {[ 'radio'].map((type) => (
    <div key={`inline-${type}`} className="mb-3">
      <Form.Check
        inline
        label="DONE"
        name="group1"
        type={type}
        id={`inline-${type}-1`}
        value={status}
        onClick={()=>SetStatus(true)}
      />
      <Form.Check
        inline
        label="INPROGRESS"
        name="group1"
        type={type}
        id={`inline-${type}-2`}
        value={status}
        onClick={()=>SetStatus(false)}
      />
      
    </div>
  ))}

                </div>
                <div  className="form-group mt-3"  style={{display:"flex"}}>
                    <label style={{width:"23%"}}>Remarks:</label>
                    <textarea value={remarks} onChange={e=>SetRemarks(e.target.value)} style={{width:"50%",height:"50px"}}/>

                </div>
                <div style={{
                  display:"flex"
                }}>
                  <div style={{width:"40%"}}>
                  <button type="submit" className="btn btn-success mt-4" onClick={(e)=>SaveData(e)} style={{margin:"0px 108px"}}>Save</button>
                  </div> 
                  <div style={{marginTop:"23px",width:"40%"}}>
                  <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          </div> 
          </div> 
                </form>
            </Modal.Body>
       
      </Modal>
       </div>  
      </div>    
      </div>  
      </Container>
     
      </Navigation>  
      </div>
  );
}
 
export default Example;