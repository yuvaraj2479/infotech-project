import React, { Component } from 'react';
import {Modal,Button} from 'react-bootstrap';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

class Adduser extends Component {
    constructor(props) {
        super(props);
        this.state={
            show:false
        }
    }
    handleClose=()=>{
        this.setState({show:false})
    }

    Adduser=()=>{
        this.setState({show:true})
    }
    render() {
        return (
            <div>
<Button onClick={this.Adduser}>ADD user</Button>

      <Modal
        show={this.state.show}
        onHide={this.handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Record</Modal.Title>
        </Modal.Header>
            <Modal.Body>
            <form>
                <div class="form-group">
                <label >Date:</label>
                    <DatePicker />
                </div>
                <div class="form-group mt-3">
                <label >user:</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Country"/>
                </div>
                <div class="form-group mt-3">
                <label >Task:</label>
                <textarea />
                </div>
                <div class="form-group mt-3">
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Country"/>
                </div>
                
                  <button type="submit" class="btn btn-success mt-4">Add Record</button>
                </form>
            </Modal.Body>
 
        <Modal.Footer>
          <Button variant="secondary" onClick={this.handleClose}>
            Close
          </Button>
          
        </Modal.Footer>
      </Modal>
            </div>
        );
    }
}

export default Adduser;
