import React, { Component } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import {Nav,} from 'react-bootstrap';
import { AiFillHome,AiFillCheckCircle, AiFillTool } from 'react-icons/ai';
import { BsFillPencilFill } from "react-icons/bs";
import { FiUser } from "react-icons/fi";



class Navigation extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
     
       name:''
    }

  }
  componentWillMount=()=>{
    console.log("gobala")
    this.setState({name:localStorage.getItem('name')})
  }
  
    render() {
         
        return (
         
          <div>
            <div style={{backgroundColor:"rgb(0, 0, 1500)",height:"55px"}}>
            <Nav variant="pills" defaultActiveKey="/home" style={{justifyContent:"flex-End",padding:"0px 20px"}}>
              <div style={{justifyContent:"center",marginRight:"15px"}}>
             <FiUser style={{height:"60px",width:"40px",color:"white",marginleft:"1450px"}} />
             </div>
             <div style={{color:"white",paddingTop:"15px",marginRight:"50px"}}>
             <h5 >{this.state.name}</h5>
             </div>
</Nav>
         
            </div>
            <div style={{display:"flex"}}>
                <Navbar  variant="dark" style={{display:"flex",width:"270px",height:"50%",backgroundColor:"#f4f6f9"}}>
               <div style={{height:"729px"}}>
              <Nav className="me-auto" style={{display:"flex",textAlign:'center',height:"50%"}}>
                  <div className='change'>
           <Nav.Link href="/Home" style={{width:"270px", display:"flex",
         backgroundColor:"#f4f6f9"  ,padding:"5px",fontSize:"20px",color:"black",borderBottom:"2px solid black" }}> 
      <div style={{width:"50%"}}>
        <AiFillHome style={{marginBottom:"10%"}}/> 
        </div>   
        <div style={{width:"50%",marginRight:"30%",fontSize:"17px",fontWeight:"bold"}}>Home</div> 
        </Nav.Link>
           <Nav.Link href="/nav/Task"style={{width:"270px", display:"flex",
         backgroundColor:"#f4f6f9"  ,padding:"5px",fontSize:"20px",color:"black",borderBottom:"2px solid black"}}>
           <div style={{width:"50%"}}>
             <AiFillCheckCircle />
             </div>
             <div style={{width:"50%",marginRight:"30%",fontSize:"17px",fontWeight:"bold"}}> Task </div>
             </Nav.Link>
      <Nav.Link href="/nav/leave"style={{width:"270px", display:"flex",
         backgroundColor:"#f4f6f9"  ,padding:"5px",fontSize:"20px",color:"black",borderBottom:"2px solid black"}}>
           <div style={{width:"50%"}}><BsFillPencilFill /></div>
           <div style={{width:"50%",marginRight:"30%",fontSize:"17px",fontWeight:"bold"}}>Leaves</div></Nav.Link>
         <Nav.Link href="/Logout"style={{width:"270px", display:"flex",
         backgroundColor:"#f4f6f9"  ,padding:"5px",fontSize:"20px",color:"black",borderBottom:"2px solid black"}}>
           <div style={{width:"50%"}}><AiFillTool /></div>
           <div style={{width:"50%",marginRight:"30%",fontSize:"17px",fontWeight:"bold"}}>Logout</div> </Nav.Link>
      </div>
    </Nav>
    </div>
  </Navbar>
  <div >
    {this.props.children}
  </div>

            </div>
            </div>
        );
    }
}

export default Navigation;

