import React, { Component } from 'react';
import Login from './login';
import 'bootstrap/dist/css/bootstrap.css';
import Navigation from './components/nav';
import Example from './components/Tk';
import Leavemodule from './components/Leavemodule'
import {BrowserRouter as Router,Route,Routes} from 'react-router-dom';





class App extends Component {
  render() {
    return (
      <Router>
        <Routes>
          <Route exact path="/" element={<Login />}/>    
          <Route exact path="/nav" element={<Navigation />}/>          
          <Route exact path="/nav/Task" element={<Example />}/>
          <Route exact path="/nav/Leave" element={<Leavemodule />}/>
          

          </Routes>
     </Router>
    );
  }
}

export default App;
