import React, { Component } from 'react';
import Navigation from './nav';
import { Button,Container,Modal, ModalBody,Form } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { AiFillEdit,AiFillDelete } from 'react-icons/ai';




class Leavemodule extends Component {
    constructor(props) {
        super(props);
        
    this.state = {
        isOpen: false,
        date: '',
        value:'',
        fromDate:'',
        toDate:'',
        size:'',
        address:'',
        days:'',
        data:[],  
        edit:false,  
        index:''
      };
    }

    
    
      openModal = (e) => this.setState({ isOpen: true }); 
      closeModal = (e) =>this.setState({ isOpen: false });
      


      handleDate=(date)=>{
        this.setState({date: date})
        }

        handleLeave=(event)=>{
            this.setState({value: event.target.value});
        }

        handleFrom=(date)=>{
            this.setState({fromDate: date})
        }

        handleTO=(date)=>{
            this.setState({toDate: date})
        }

        handlesession=(event)=>{
            this.setState({size:event.target.value});
        }

        handleText=(event)=>{
            this.setState({address: event.target.value});
        }
         
        handleDays=(event)=>{
            this.setState({days: event.target.value});
        }

        onFormSubmit=(e,id)=> {
          
          
          const i={
              Date:this.state.date.toLocaleDateString(),
              Leave:this.state.value,
              From:this.state.fromDate.toLocaleDateString(),
              To:this.state.toDate.toLocaleDateString(),
              Session:this.state.size,
              purpose:this.state.address,
              Days:this.state.days

          }
          
      
          
         
         
        //   this.state.data.push(i)
          this.setState({isOpen:false}) 
           if(this.state.edit===false){
               this.state.data.push(i)
           }else{
               this.state.data.splice(this.state.index,1);
               this.state.data.push(i);
           }

        
          
           this.setState({  date: ''})
           this.setState({  value:''})
           this.setState({ fromDate:''})
           this.setState({ toDate:''})
           this.setState({  size:''})
           this.setState({  address:''})
           this.setState({ days:'' })

        }

    
        handleEdit=(item,i)=>{
           
           this.setState({isOpen:true})
           this.setState({edit:true})
          this.setState({index:i})
          
        
        //    this.setState({date:item.Date});
           this.setState({value:item.Leave});
        //    this.setState({fromDate:item.From});
        //    this.setState({toDate:item.To});
           this.setState({size:item.Session});
           this.setState({address:item.purpose});
           this.setState({days:item.Days});
        }
         
       

        handleDelete=(id,i)=>{
           this.state.data.splice(id,1);
           this.setState({i})
        }
        
    

    
    render() {
       
        return (
            
            <div>
                <Navigation>
                <Container>
                    <div className="container ">
                        <div className="crud shadow-lg p-3 mb-5 mt-5 bg-body rounded" style={{width:"1050px",paddingLeft:"1000px",margin:"60px"}}>
                            <div className="row ">
                                <div className="col-sm-3 mt-5 mb-4 text-gred">
                                </div>
                                <div className="col-sm-3 offset-sm-2 mt-5 mb-4 text-gred" style={{color:"green"}}><h2><b>Leaves</b></h2></div>
                                <div className="col-sm-3 offset-sm-1  mt-5 mb-4 text-gred" style={{display:"flex",justifyContent:'center'}}>
                                <Button variant="primary" onClick={this.openModal}>
                                    Add Leaves
                                </Button>
                                </div>
                            </div>
                            <div className="model_box">
                            <>
                            
                            <Modal show={this.state.isOpen} onHide={this.closeModal}>
                            <Modal.Header closeButton>
                            <Modal.Title>Add Leave</Modal.Title>
                            </Modal.Header>
                            <ModalBody>
                                <form >
                                <div className="form-group" style={{display:"flex"}}>
                                <Form.Label style={{width:"30%"}}>Applied date:</Form.Label>
                                {/* <Form.Control type="date" name="dob" placeholder="Choose the Date" selected={ this.state.Date } dateformat="dd/MM/yyyy" onChange={ this.handleDate }/> */}
                              
                                <DatePicker
                                selected={this.state.date}
                                onChange={this.handleDate} 
                                />
                               
                                </div>
                               
                                <div className="form-group mt-3" style={{display:"flex"}}>
                                    <Form.Label style={{width:"30%"}}>Leave type:</Form.Label>
                                    <Form.Select aria-label="Default select example" value={this.state.value} onChange={this.handleLeave} >

                                    <option value="CL-Casual Leave">CL-Casual Leave</option>
                                    <option value="ML-Medical Leave">ML-Medical Leave</option>       
                                    </Form.Select>
                                </div>
                                <div className="form-group mt-3" style={{display:"flex"}}>
                                <Form.Label style={{width:"30%"}}>From Date:</Form.Label>
                                <DatePicker name="dob"  placeholder="Choose the Date"  selected={ this.state.fromDate }  dateformat="dd/MM/yyyy" onChange={ this.handleFrom }/>
                                </div>
                                <div className="form-group mt-3" style={{display:"flex"}}>
                                <Form.Label style={{width:"30%"}}>To Date:</Form.Label>
                                <DatePicker name="dob" placeholder="Choose the Date" selected={ this.state.toDate }  dateformat="dd/MM/yyyy" onChange={ this.handleTO } />
                                </div>
                                <div className="form-group mt-3" style={{display:"flex"}}>
                                <Form.Label style={{width:"23%"}}>Session:</Form.Label>
                                {[ 'radio'].map((type) => (
    <div key={`inline-${type}`} className="mb-3">
      <Form.Check
        inline
        label="FULL"
        name="group1"
        type={type}
        id={`inline-${type}-1`}
        value="full"
        checked={this.state.size === "full"}
        onChange={this.handlesession}
      />
      <Form.Check
        inline
        label="FN"
        name="group1"
        type={type}
        id={`inline-${type}-2`}
        value="fn"
        checked={this.state.size === "fn"}
        onChange={this.handlesession}
      />
      <Form.Check
        inline
        name="group1"
        label="AN"
        type={type}
        id={`inline-${type}-3`}
        value="an"
        checked={this.state.size === "an"}
        onChange={this.handlesession}
      />
    </div>
    ))}
                                </div>
                                <div className="form-group mt-1" style={{display:"flex"}}>
                                <Form.Label style={{width:"30%"}}>purpose:</Form.Label>
                                <Form.Control as="textarea" rows="3" name="address" onChange={this.handleText} value={this.state.address} />
                                </div>
                                <div className="form-group mt-3" style={{display:"flex"}}>
                                <Form.Label style={{width:"30%"}}>No of days:</Form.Label>
                                <Form.Control type="numeric" name="days" onChange={this.handleDays} value={this.state.days}></Form.Control>   
                                </div>
                                <div  className="form-group mt-3" >
                                    <Button onClick={ ()=>this.onFormSubmit() } style={{margin:"0px 225px"}}> Save</Button>   
                                </div>
                                </form>
                            </ModalBody>
                            </Modal>
        
      </>
      <div className="row">
      <table className="table table-striped table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Applied date</th>
                                        <th>Leave type</th>
                                        <th>From Date</th>
                                        <th>To Date</th>
                                        <th>Session</th>
                                        <th>purpose</th>
                                        <th>No of days</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                {this.state.data.map((item,i)=>
                                    <tr key={i} >
                                        <td>{item.Date}</td>
                                        <td>{item.Leave}</td>
                                        <td>{item.From}</td>
                                        <td>{item.To}</td>
                                        <td>{item.Session}</td>
                                        <td>{item.purpose}</td>
                                        <td>{item.Days}</td>
                                        <td><AiFillEdit onClick={()=>this.handleEdit(item,i)}/><AiFillDelete onClick={()=>this.handleDelete(i)}></AiFillDelete></td>
                                    </tr>)}
                                </tbody>
                                
                                </table>
                                </div>

                            </div>

                        </div>

                    </div>



                </Container>
                
                </Navigation>
            </div>
        );
        
    }
   
    
}



export default Leavemodule;


