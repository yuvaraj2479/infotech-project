export default function auth(){
    const user = localStorage.getItem('name')

    if(!user){
        window.location='/'
    }else{

    }
}
