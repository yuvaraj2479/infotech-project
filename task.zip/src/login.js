import React, { Component } from 'react';
import {Container,Form,Button, Card,Row} from 'react-bootstrap';
import axios from 'axios';







class Login extends Component {
    constructor({}) {
        super();
        this.state={
            username:'',
            password:'',
           
            
        }
    }
    change=(e,)=>{
      this.setState({
          [e.target.name]: e.target.value
               } 
        )
      
    }
    Submit=(e)=>{
        
        e.preventDefault()
        // console.log(this.state.username)
        // const logindata={
        //     username:this.state.username,
        //     password:this.state.password
        // }
        
        

    //    if(this.state.username !='' && this.state.password === 'admin')
       
    //    {
    //        console.log("hello")
    //        localStorage.setItem("name",this.state.username)
    //        alert('login succesful')
    //        window.location='/nav'
    //    }else{

    //         alert ('invalid username and password')
    //    }
    //     console.log(this.state)
    
    
   

    axios
  .post('https://raves-task-api.herokuapp.com/api/auth/local',{
    identifier: this.state.username,
    password: this.state.password,
  })
  .then(response => {
    // Handle success.
    // console.log('Well done!');
    // console.log('User profile', response.data.logindata);
    // console.log('User token', response.data.jwt);
    console.log(response)
    localStorage.setItem("name",this.state.username)
    window.location='/nav'
  })
  .catch(error => {
    // Handle error.
    console.log('An error occurred:', error.response);
    alert('invalid username and password' )
  }); 
  
    }
  




    
    render() {
        return (
            <Container>
              <div style={{display:"flex",paddingtop:"60%",marginTop:"15%",marginLeft:"30%"}}>

                  <Card style={{width:"50%",padding:20,display:"flex",margintop:"80%",borderRadius:"20px"}}>
                     <img src='/images/logo.png' className='img-fluid ' alt='logo' style={{width:"30%",marginLeft:"35%"}}/>
              
                      <div>
                      
                  <Row className="mb-3">
                      <Form >
                         <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>UserName</Form.Label>
                              <Form.Control onChange={(e)=>this.change(e)} type="text" name='username' value={this.state.username} placeholder="Enter username" />
                       </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicPassword">
                      <Form.Label>Password</Form.Label>
                           <Form.Control onChange={(e)=>this.change(e)} type="password" name='password' value={this.state.password} placeholder="Enter password" />
                       </Form.Group>
                       
                      <Button  onClick={this.Submit}  variant="primary" type="submit" style={{display:"flex",textAlign:"center",
                          justifyContent:"center",marginLeft:"43%",borderRadius:"10px",width:"20%",color:"white" }}>
                            Login  
                        </Button>
                       
                       </Form>
                       </Row>
                        </div>

        </Card>  
        </div>

        </Container>
            
        );
    }
}

export default Login;





