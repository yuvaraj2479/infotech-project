module.exports = ({ env }) => ({
  auth: {
    secret: env('ADMIN_JWT_SECRET', '3c52b27f1e6b2f5675d1e6c88150200a'),
  },
});
